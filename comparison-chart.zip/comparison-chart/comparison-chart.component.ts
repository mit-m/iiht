import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";
import { Router } from '@angular/router';


@Component({
  selector: 'app-comparison-chart',
  templateUrl: './comparison-chart.component.html',
  styleUrls: ['./comparison-chart.component.css']
})
export class ComparisonChartComponent implements OnInit {

  comparisonChart: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.comparisonChart = this.formBuilder.group(
      {
        selectSE1: new FormControl('', [
          Validators.required
        ]),
        selectSE2: new FormControl('', [
          Validators.required
        ]),
        fromPeriod1: new FormControl('', [
          Validators.required
        ]),
        fromPeriod2: new FormControl('', [
          Validators.required
        ]),
        toPeriod1: new FormControl('', [
          Validators.required
        ]),
        toPeriod2: new FormControl('', [
          Validators.required
        ]),
        companyName1: new FormControl('', [
          Validators.required
        ]),
        companyName2: new FormControl('', [
          Validators.required
        ]),



      });
  }

get f() {
  return this.comparisonChart.controls;
}

  onSubmit() {
    this.submitted = true;
    if (this.comparisonChart.invalid) {
      return;
    }

   // console.log(this.comparisonChart.value);

    const chartObject = {
      // selectCompSec1: this.comparisonChart.value["selectCS1"],
      // selectCompSec2: this.comparisonChart.value["selectCS2"],
      selectStoExch1: this.comparisonChart.value["selectSE1"],
      selectStoExch2: this.comparisonChart.value["selectSE2"],
      fromPeriod1: this.comparisonChart.value["fromPeriod1"],
      fromPeriod2: this.comparisonChart.value["fromPeriod2"],
      toPeriod1: this.comparisonChart.value["toPeriod1"],
      toPeriod2: this.comparisonChart.value["toPeriod2"],
      companyName1: this.comparisonChart.value["companyName1"],
      companyName2: this.comparisonChart.value["companyName2"],
    };

    console.log(chartObject);



  }
}
